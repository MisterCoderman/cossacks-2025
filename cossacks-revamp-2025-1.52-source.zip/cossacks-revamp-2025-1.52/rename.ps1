﻿#!/usr/bin/env pwsh

# Получаем все файлы в текущей директории и поддиректориях
$files = Get-ChildItem -Recurse -File

foreach ($file in $files) {
    # Убираем из начала абсолютный путь до текущей папки и разделитель
    $cwd = (Get-Location).Path
    $relativePath = $file.FullName.Substring($cwd.Length + 1)

    # Проверяем наличие вложенных папок (есть хотя бы один '\')
    if ($relativePath -match '\\') {
        # Заменяем '\' на '+'
        $newFileName = $relativePath -replace '\\','+'

        # Копируем файл в новое имя
        Copy-Item -LiteralPath $file.FullName -Destination $newFileName

        Write-Host "Copy and rename file: $($file.FullName) -> $newFileName"
    }
}

Write-Host "Finish"
